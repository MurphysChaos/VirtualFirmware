/*******************************************************************************

  Intel 1 Gigabit PCI Express Linux driver
  Copyright(c) 1999 - 2011 Intel Corporation.

  This program is free software; you can redistribute it and/or modify it
  under the terms and conditions of the GNU General Public License,
  version 2, as published by the Free Software Foundation.

  This program is distributed in the hope it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
  more details.

  You should have received a copy of the GNU General Public License along with
  this program; if not, write to the Free Software Foundation, Inc.,
  51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.

  The full GNU General Public License is included in this distribution in
  the file called "COPYING".

  Contact Information:
  e1000-devel Mailing List <e1000-devel@lists.sourceforge.net>
  Intel Corporation, 5200 N.E. Elam Young Parkway, Hillsboro, OR 97124-6497

*******************************************************************************/

#ifndef _E1000_ADMINQ_H_
#define _E1000_ADMINQ_H_

#include "e1000_hw.h"

/* Admin Queue command opcodes */
enum e1000_admin_queue_cmd {
	/* aq commands */
	e1000_aqc_get_version 			= 0x0001,
	e1000_aqc_driver_heartbeat		= 0x0002,
};

/*
 * Basic adminq descriptor
 */
struct e1000_aq_desc {
	__le16 flags;
	__le16 opcode;
	__le16 datalen;
	__le16 retval;
	__le32 cookie_high;
	__le32 cookie_low;
	__le32 param0;
	__le32 param1;
	__le32 addr_high;
	__le32 addr_low;
};

#define E1000_ADMINQ_DESC(R, i)   \
	(&(((struct e1000_aq_desc *)((R).desc))[i]))

#define E1000_ADMINQ_DESC_ALIGNMENT 4096
struct e1000_adminq_ring {
	void *desc;		/* Descriptor ring memory */

	dma_addr_t dma;		/* Physical address of the ring */
	u16 count;		/* Number of descriptors */
	u16 rx_buf_len;		/* Admin Receive Queue buffer length */

	struct e1000_aq_bi *asq_bi;

	/* used for interrupt processing */
	u16 next_to_use;
	u16 next_to_clean;

	/* used for queue tracking */
	u32 head;
	u32 tail;
};

struct e1000_aq_bi {
	dma_addr_t dma;
	void *buf;
	u32 size;
};

/* general information */
#define E1000_AQ_LARGE_BUF	512
#define E1000_ASQ_CMD_TIMEOUT	100000 /* TODO - shrink later from KVM usage */

/* error codes */
enum e1000_admin_queue_err {
	E1000_AQ_RC_OK =		0,	/* success */
	E1000_AQ_RC_EPERM =	1,	/* Operation not permitted */
	E1000_AQ_RC_ENOENT =	2,	/* No such element */
	E1000_AQ_RC_ESRCH =	3,	/* Bad opcode */
	E1000_AQ_RC_EINTR = 	4,	/* operation interrupted */
	E1000_AQ_RC_EIO =	5,	/* I/O error */
	E1000_AQ_RC_ENXIO =	6,	/* No such resource */
	E1000_AQ_RC_E2BIG =	7,	/* Arg too long */
	E1000_AQ_RC_EAGAIN =	8,	/* Try again */
	E1000_AQ_RC_ENOMEM =	9,	/* Out of memory */
	E1000_AQ_RC_EACCES =	10,	/* Permission denied */
	E1000_AQ_RC_EFAULT =	11,	/* Bad address */
	E1000_AQ_RC_EBUSY = 	12,	/* Device or resource busy */
	E1000_AQ_RC_EEXIST =	13,	/* Attempt to create something that exists */
	E1000_AQ_RC_EINVAL =	14,	/* Invalid argument */
	E1000_AQ_RC_ENOTTY =	15,	/* Not a typewriter */
	E1000_AQ_RC_ENOSPC =	16,	/* No space left or alloc failure */
	E1000_AQ_RC_ENOSYS =	17,	/* Function not implemented */
	E1000_AQ_RC_ERANGE =	18,	/* Parameter out of range */
	E1000_AQ_RC_EFLUSHED =	19,	/* Command flushed because a previous
						 command completed in error */
	/* SW use if the command times out with no WB */
	E1000_AQ_ERR_INVALID_BUFF_SIZE = 0xfffd,
	E1000_AQ_ERR_QUEUE_FULL	=	0xfffe,
	E1000_AQ_ERR_TIMEOUT =		0xffff
};

/* command flags and offsets */
#define E1000_AQ_FLAG_DD_OFF_SHIFT	0
#define E1000_AQ_FLAG_CMP_OFF_SHIFT	1
#define E1000_AQ_FLAG_ERR_OFF_SHIFT	2
#define E1000_AQ_FLAG_VFE_OFF_SHIFT	3
#define E1000_AQ_FLAG_LB_OFF_SHIFT	4
#define E1000_AQ_FLAG_RD_OFF_SHIFT	0xA
#define E1000_AQ_FLAG_VFC_OFF_SHIFT	0xB
#define E1000_AQ_FLAG_BUF_OFF_SHIFT	0xC
#define E1000_AQ_FLAG_SI_OFF_SHIFT	0xD
#define E1000_AQ_FLAG_EI_OFF_SHIFT	0xE
#define E1000_AQ_FLAG_FE_OFF_SHIFT	0xF

#define E1000_AQ_FLAG_DD		(1 << E1000_AQ_FLAG_DD_OFF_SHIFT)
#define E1000_AQ_FLAG_CMP 		(1 << E1000_AQ_FLAG_CMP_OFF_SHIFT)
#define E1000_AQ_FLAG_ERR		(1 << E1000_AQ_FLAG_ERR_OFF_SHIFT)
#define E1000_AQ_FLAG_VFE		(1 << E1000_AQ_FLAG_VFE_OFF_SHIFT)
#define E1000_AQ_FLAG_LB		(1 << E1000_AQ_FLAG_LB_OFF_SHIFT)
#define E1000_AQ_FLAG_RD		(1 << E1000_AQ_FLAG_RD_OFF_SHIFT)
#define E1000_AQ_FLAG_VFC		(1 << E1000_AQ_FLAG_VFC_OFF_SHIFT)
#define E1000_AQ_FLAG_BUF		(1 << E1000_AQ_FLAG_BUF_OFF_SHIFT)
#define E1000_AQ_FLAG_SI		(1 << E1000_AQ_FLAG_SI_OFF_SHIFT)
#define E1000_AQ_FLAG_EI		(1 << E1000_AQ_FLAG_EI_OFF_SHIFT)
#define E1000_AQ_FLAG_FE		(1 << E1000_AQ_FLAG_FE_OFF_SHIFT)

#define E1000_PF_ATQBAH             	0x00006000
#define E1000_PF_ATQBAH_ATQBAH_SHIFT	0
#define E1000_PF_ATQBAH_ATQBAH_MASK 	(0xFFFFFFFF << E1000_PF_ATQBAH_ATQBAH_SHIFT)
#define E1000_PF_ATQBAL             	0x00006004
#define E1000_PF_ATQBAL_ATQBAL_SHIFT	0
#define E1000_PF_ATQBAL_ATQBAL_MASK 	(0xFFFFFFFF << E1000_PF_ATQBAL_ATQBAL_SHIFT)
#define E1000_PF_ATQH           	0x00006008
#define E1000_PF_ATQH_ATQH_SHIFT	0
#define E1000_PF_ATQH_ATQH_MASK 	(0x3FF << E1000_PF_ATQH_ATQH_SHIFT)
#define E1000_PF_ATQLEN                	0x0000600C
#define E1000_PF_ATQLEN_ATQLEN_SHIFT   	0
#define E1000_PF_ATQLEN_ATQLEN_MASK    	(0x3FF << E1000_PF_ATQLEN_ATQLEN_SHIFT)
#define E1000_PF_ATQLEN_ATQENABLE_SHIFT	31
#define E1000_PF_ATQLEN_ATQENABLE_MASK 	(0x1 << E1000_PF_ATQLEN_ATQENABLE_SHIFT)
#define E1000_PF_ATQT           	0x00006010
#define E1000_PF_ATQT_ATQT_SHIFT	0
#define E1000_PF_ATQT_ATQT_MASK 	(0x3FF << E1000_PF_ATQT_ATQT_SHIFT)

/* command structures */

#endif /* _E1000_ADMINQ_H_ */
